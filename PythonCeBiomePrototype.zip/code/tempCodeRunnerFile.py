oin('assets','images','other','icon.png')).convert_alpha())
        self.clock = pygame.time.Clock()