from levels.worldgen_instr import *

# This file will hold a function that creates "features"
# E.g.: Lake, Pond, Air Borders...



# def createFeature(arr, featureId):

#     if featureId == "air_borders":
#         arrToReturn = wrlGen_RingAt()

