
chances_forest = {
    "tree": 0.5,
    "water": 0.075,
    "flower": 0.15,
    "rock": 0.05
}

chances_aspen = {
    "tree": 0.4,
    "water": 0.1,
    "flower": 0.175,
    "rock": 0.05
}

chances_taiga = {
    "tree": 0.55,
    "water": 0.15,
    "flower": 0.15,
    "rock": 0.05
}

chances_prairie = {
    "tree": 0.05,
    "water": 0.08,
    "flower": 0.25,
    "rock": 0.15
}

chances_dead = {
    "tree": 0.425,
    "water": 0.1,
    "flower": 0,
    "rock": 0.15
}

chances_swamp = {
    "tree": 0.35,
    "water": 0.25,
    "flower": 0.1,
    "rock": 0.05
}

