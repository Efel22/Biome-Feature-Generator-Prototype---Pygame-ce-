# This hols words that will join together to form
# a level file name :D
from random import choice

FirstWord = {"Titans", "Time", "Trees", "Oaks", "Warriors", "Wars", "Duels", "Swords", "Calamity", "Oasis", "Volcano", "Lakes", "Fires",
             "Moons", "Suns", "Shadows", "Lights", "Beacons", "Serpents", "Fighters", "Mages", "Magic", "Sorcery", "Stars", "Moments",
             "Fissures", "Sunset", "Rainbow", "Rivers", "Oceans", "Deltas", "Mountains", "Valleys", "Plateaus", "Ravines", "Baskets", 
             "Curtains", "Breeze", "Eyes", "Limbs", "Bays", "Rangers", "Archers", "Cannons", "Cities", "Buttons", "Roses", "Spells",
             "Crafters", "Shapers", "Masters", "Hideouts", "Summoners", "Conquests", "Peace", "Scars", "Painters"
             }
SecondWord = {"of", "and", "of the", "without", "with"}
ThirdWord = FirstWord

levelNameDict = {
    "first": FirstWord,
    "second": SecondWord,
    "third": ThirdWord
}



