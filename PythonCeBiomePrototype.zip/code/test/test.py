import pygame
import sys

# Inicializar Pygame
pygame.init()

# Configuración de la pantalla
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Juego de Pelea")

# Colores
WHITE = (255, 255, 255)
RED = (255, 0, 0)
BLUE = (0, 0, 255)

# Reloj para controlar la velocidad de fotogramas
clock = pygame.time.Clock()

# Clase para el jugador
class Player(pygame.sprite.Sprite):
    def __init__(self, color, x, y, width, height):
        super().__init__()
        self.image = pygame.Surface((width, height))
        self.image.fill(color)
        self.rect = self.image.get_rect()
        self.rect.topleft = (x, y)
        self.speed = 5
        self.health = 100

    def move(self, dx, dy):
        self.rect.x += dx * self.speed
        self.rect.y += dy * self.speed

    def attack(self, target):
        if self.rect.colliderect(target.rect):
            target.health -= 10
            print(f"Salud del objetivo: {target.health}")

    def draw_health(self):
        pygame.draw.rect(screen, RED, (self.rect.x, self.rect.y - 10, 50, 5))
        pygame.draw.rect(screen, BLUE, (self.rect.x, self.rect.y - 10, self.health / 2, 5))

# Crear jugadores
player1 = Player(RED, 100, HEIGHT // 2, 50, 50)
player2 = Player(BLUE, WIDTH - 150, HEIGHT // 2, 50, 50)

# Bucle principal del juego
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Capturar teclas presionadas
    keys = pygame.key.get_pressed()

    # Movimiento del jugador 1
    if keys[pygame.K_a]:
        player1.move(-1, 0)
    if keys[pygame.K_d]:
        player1.move(1, 0)
    if keys[pygame.K_w]:
        player1.move(0, -1)
    if keys[pygame.K_s]:
        player1.move(0, 1)
    if keys[pygame.K_SPACE]:
        player1.attack(player2)

    # Movimiento del jugador 2
    if keys[pygame.K_LEFT]:
        player2.move(-1, 0)
    if keys[pygame.K_RIGHT]:
        player2.move(1, 0)
    if keys[pygame.K_UP]:
        player2.move(0, -1)
    if keys[pygame.K_DOWN]:
        player2.move(0, 1)
    if keys[pygame.K_RCTRL]:
        player2.attack(player1)

    # Actualizar pantalla
    screen.fill(WHITE)
    player1.draw_health()
    player2.draw_health()
    screen.blit(player1.image, player1.rect)
    screen.blit(player2.image, player2.rect)

    # Verificar si algún jugador ha perdido toda su salud
    if player1.health <= 0 or player2.health <= 0:
        print("¡Juego terminado!")
        running = False

    # Actualizar pantalla
    pygame.display.flip()

    # Controlar la velocidad de fotogramas
    clock.tick(60)

# Salir del juego
pygame.quit()
sys.exit()